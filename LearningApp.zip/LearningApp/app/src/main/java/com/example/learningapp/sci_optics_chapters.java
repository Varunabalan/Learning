package com.example.learningapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class sci_optics_chapters extends AppCompatActivity {


    Button a;
    Button b;
    Button c;
    Button d;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sci_optics_chapters);

        a = (Button) findViewById(R.id.btnreflection);
        b=(Button) findViewById(R.id.btnmirrors);
        c=(Button) findViewById(R.id.btnrefraction);
        d=(Button) findViewById(R.id.btnlenses);



        a.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent int1= new Intent(sci_optics_chapters.this, sci_optics_reflection.class);
                startActivity(int1);
            }




        });

        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent int2= new Intent(sci_optics_chapters.this, sci_optics_mirrors.class);
                startActivity(int2);
            }




        });

        c.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent int2= new Intent(sci_optics_chapters.this,sci_optics_refraction.class);
                startActivity(int2);
            }




        });

        d.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent int2= new Intent(sci_optics_chapters.this, sci_optics_lenses.class);
                startActivity(int2);
            }




        });

    }
}


