package com.example.learningapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class sci_waves_chapters extends AppCompatActivity {


    Button a;
    Button b;
    Button c;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sci_waves_chapters);

        a = (Button) findViewById(R.id.btnmechanical);
        b=(Button) findViewById(R.id.btnsounds);
        c=(Button) findViewById(R.id.btninstruments);


        a.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent int1= new Intent(sci_waves_chapters.this, sci_waves_mechanical.class);
                startActivity(int1);
            }




        });

        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent int2= new Intent(sci_waves_chapters.this, sci_waves_sounds.class);
                startActivity(int2);
            }




        });

        c.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent int2= new Intent(sci_waves_chapters.this, sci_waves_instruments.class);
                startActivity(int2);
            }




        });

    }
}


