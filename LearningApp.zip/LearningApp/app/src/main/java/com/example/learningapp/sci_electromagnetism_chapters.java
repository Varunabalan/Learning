package com.example.learningapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class sci_electromagnetism_chapters extends AppCompatActivity {


    Button a;
    Button b;
    Button c;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sci_electromagnetism_chapters);

        a = (Button) findViewById(R.id.btnmagnetism);
        b=(Button) findViewById(R.id.btnmagneticeffect);
        c=(Button) findViewById(R.id.btninduction);


        a.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent int1= new Intent(sci_electromagnetism_chapters.this, sci_electromagnetism_magnetism.class);
                startActivity(int1);
            }




        });

        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent int2= new Intent(sci_electromagnetism_chapters.this, sci_electromagnetism_magneticeffects.class);
                startActivity(int2);
            }




        });

        c.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent int2= new Intent(sci_electromagnetism_chapters.this,sci_electromagnetism_induction.class);
                startActivity(int2);
            }




        });

    }
}


