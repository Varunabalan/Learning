package com.example.learningapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class sci_animal_voc_select_medium extends AppCompatActivity {
    Button tamil;
    Button sinhala;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sci_animal_voc_select_medium);

        tamil = (Button) findViewById(R.id.btntamil);
        sinhala=(Button) findViewById(R.id.btnsinhala);


        tamil.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent int1= new Intent(sci_animal_voc_select_medium.this, sci_vocabulary_tamil_animal.class);
                startActivity(int1);
            }




        });

        sinhala.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent int2= new Intent(sci_animal_voc_select_medium.this, sci_vocabulary_sinhala_animal.class);
                startActivity(int2);
            }




        });

    }
}