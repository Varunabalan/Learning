package com.example.learningapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class sci_photosyn_chapters extends AppCompatActivity {


    Button factors;
    Button products;
    Button importance;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sci_photosyn_chapters);

        factors = (Button) findViewById(R.id.btnfactors);
        products=(Button) findViewById(R.id.btnproducts);
       importance=(Button) findViewById(R.id.btnimportance);


        factors.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent int1= new Intent(sci_photosyn_chapters.this, sci_photosyn_factors.class);
                startActivity(int1);
            }




        });

        products.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent int2= new Intent(sci_photosyn_chapters.this, sci_photosyn_products.class);
                startActivity(int2);
            }




        });

      importance.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent int2= new Intent(sci_photosyn_chapters.this, sci_photosyn_importance.class);
                startActivity(int2);
            }




        });

    }
}


