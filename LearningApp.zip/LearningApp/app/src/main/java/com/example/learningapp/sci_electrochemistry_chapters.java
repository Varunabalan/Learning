package com.example.learningapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class sci_electrochemistry_chapters extends AppCompatActivity {


    Button a;
    Button b;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sci_electrochemistry_chapters);

       a = (Button) findViewById(R.id.btncells);
        b=(Button) findViewById(R.id.btnelectrolysis);


       a.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent int1= new Intent(sci_electrochemistry_chapters.this, sci_electrochemistry_electrochemicalcells.class);
                startActivity(int1);
            }




        });

       b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent int2= new Intent(sci_electrochemistry_chapters.this, sci_electrochemistry_electrolysis.class);
                startActivity(int2);
            }




        });

    }
}


