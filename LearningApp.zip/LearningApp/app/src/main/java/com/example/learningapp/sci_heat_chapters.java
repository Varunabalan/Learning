package com.example.learningapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class sci_heat_chapters extends AppCompatActivity {


    Button a;
    Button b;
    Button c;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sci_heat_chapters);

        a = (Button) findViewById(R.id.btntemperature);
        b=(Button) findViewById(R.id.btnheat);
        c=(Button) findViewById(R.id.btnmatter);


        a.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent int1= new Intent(sci_heat_chapters.this, sci_heat_temperature.class);
                startActivity(int1);
            }




        });

        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent int2= new Intent(sci_heat_chapters.this, sci_heat_heat.class);
                startActivity(int2);
            }




        });

        c.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent int2= new Intent(sci_heat_chapters.this,sci_heat_matter.class);
                startActivity(int2);
            }




        });

    }
}


