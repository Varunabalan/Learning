package com.example.learningapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class sci_biosphere_chapters extends AppCompatActivity {


    Button a;
    Button b;
    Button c;
    Button d;
    Button e;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sci_biosphere_chapters);

       a = (Button) findViewById(R.id.btnlevels);
        b=(Button) findViewById(R.id.btnecosystems);
       c=(Button) findViewById(R.id.btnpollution);
        d=(Button) findViewById(R.id.btnlifestyle);
        e=(Button) findViewById(R.id.btndevelopment);


        a.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent int1= new Intent(sci_biosphere_chapters.this, sci_biosphere_levels.class);
                startActivity(int1);
            }




        });

        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent int2= new Intent(sci_biosphere_chapters.this, sci_biosphere_ecosystems.class);
                startActivity(int2);
            }




        });

        c.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent int2= new Intent(sci_biosphere_chapters.this, sci_biosphere_pollution.class);
                startActivity(int2);
            }




        });


        d.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent int2= new Intent(sci_biosphere_chapters.this, sci_biosphere_lifestyle.class);
                startActivity(int2);
            }




        });


        e.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent int2= new Intent(sci_biosphere_chapters.this, sci_biosphere_development.class);
                startActivity(int2);
            }




        });


    }
}


