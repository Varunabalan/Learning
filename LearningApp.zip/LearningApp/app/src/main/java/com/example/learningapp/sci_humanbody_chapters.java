package com.example.learningapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class sci_humanbody_chapters extends AppCompatActivity {


    Button digestion;
    Button respiration;
    Button excretion;
    Button circulation;
    Button coordination;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sci_humanbody_chapters);

      digestion= (Button) findViewById(R.id.btndigestion);
        respiration=(Button) findViewById(R.id.btnrespiration);
        excretion=(Button) findViewById(R.id.btnexcretion);
        circulation=(Button) findViewById(R.id.btncirculation);
        coordination=(Button) findViewById(R.id.btncoordination);


       digestion.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent int1= new Intent(sci_humanbody_chapters.this, sci_humanbody_digestion.class);
                startActivity(int1);
            }




        });

        respiration.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent int2= new Intent(sci_humanbody_chapters.this, sci_humanbody_respiration.class);
                startActivity(int2);
            }




        });

      excretion.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent int2= new Intent(sci_humanbody_chapters.this, sci_humanbody_excretion.class);
                startActivity(int2);
            }




        });

       circulation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent int2= new Intent(sci_humanbody_chapters.this, sci_humanbody_circulation.class);
                startActivity(int2);
            }




        });

      coordination.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent int2= new Intent(sci_humanbody_chapters.this, sci_humanbody_coordination.class);
                startActivity(int2);
            }




        });
    }
}


