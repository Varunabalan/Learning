package com.example.learningapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class sci_electronics_chapters extends AppCompatActivity {


    Button a;
    Button b;
    Button c;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sci_electronics_chapters);

        a = (Button) findViewById(R.id.btnintroduction);
        b=(Button) findViewById(R.id.btnjunctions);
        c=(Button) findViewById(R.id.btncurrents);


        a.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent int1= new Intent(sci_electronics_chapters.this, sci_electronics_introduction.class);
                startActivity(int1);
            }




        });

        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent int2= new Intent(sci_electronics_chapters.this, sci_electronics_junctions.class);
                startActivity(int2);
            }




        });

        c.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent int2= new Intent(sci_electronics_chapters.this, sci_electronics_currents.class);
                startActivity(int2);
            }




        });

    }
}


