package com.example.learningapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class sci_power_chapters extends AppCompatActivity {


    Button a;
    Button b;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sci_power_chapters);

        a = (Button) findViewById(R.id.btnappliences);
        b=(Button) findViewById(R.id.btncircuits);


        a.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent int1= new Intent(sci_power_chapters.this, sci_power_appliences.class);
                startActivity(int1);
            }




        });

        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent int2= new Intent(sci_power_chapters.this, sci_power_circuits.class);
                startActivity(int2);
            }




        });

    }
}


