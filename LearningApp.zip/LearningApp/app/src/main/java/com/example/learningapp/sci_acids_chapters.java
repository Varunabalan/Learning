package com.example.learningapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class sci_acids_chapters extends AppCompatActivity {


    Button a;
    Button b;
    Button c;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sci_acids_chapters);

       a = (Button) findViewById(R.id.btnacids);
     b=(Button) findViewById(R.id.btnbases);
        c=(Button) findViewById(R.id.btnsalts);


        a.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent int1= new Intent(sci_acids_chapters.this, sci_acids_acids.class);
                startActivity(int1);
            }




        });

        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent int2= new Intent(sci_acids_chapters.this, sci_acids_bases.class);
                startActivity(int2);
            }




        });

       c.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent int2= new Intent(sci_acids_chapters.this, sci_acids_salts.class);
                startActivity(int2);
            }




        });

    }
}


