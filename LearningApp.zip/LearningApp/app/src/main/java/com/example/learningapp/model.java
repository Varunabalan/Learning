package com.example.learningapp;

public class model
{
    String filename, fileurl;
    int nod,nol,nov;

    public model() {
    }

    public model(String filename, String fileurl) {
        this.filename = filename;
        this.fileurl = fileurl;

    }

    public String getFilename() {
        return filename;
    }

    public void setFilename(String filename) {
        this.filename = filename;
    }

    public String getFileurl() {
        return fileurl;
    }

    public void setFileurl(String fileurl) {
        this.fileurl = fileurl;
    }


}
