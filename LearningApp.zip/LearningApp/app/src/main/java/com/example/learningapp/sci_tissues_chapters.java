package com.example.learningapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class sci_tissues_chapters extends AppCompatActivity {


    Button plant;
    Button animal;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sci_tissues_chapters);

        plant = (Button) findViewById(R.id.btnplant);
        animal=(Button) findViewById(R.id.btnanimal);


        plant.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent int1= new Intent(sci_tissues_chapters.this, sci_tissues_plant.class);
                startActivity(int1);
            }




            });

        animal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent int2= new Intent(sci_tissues_chapters.this, sci_tissues_animal.class);
                startActivity(int2);
            }




        });

    }
}


